<?php
    //Extraer los datos del POST
    extract($_POST);
    //Conectar con el servidor de datos y acceder a la BD//
    $cnx = new mysqli("localhost","root","root","BDTICESTUDIOS");
    if($cnx->connect_errno){
        die("Error de conexión");
    }
    //Insertar los datos en la BD//
    //Preparamos la SQL//
    $SQL = "Insert Into cursos (nombre, especialidad, fechaInicio, fechaFin, plazas) values ('$nombre','$especialidad','$fechaInicio','$fechaFin',$plazas)";
    //Ejecutamos la SQL//
    $cnx->query($SQL);
    if($cnx->error){
        echo "Se ha producido un error al grabar los datos";
    }
    else {
        echo "El curso ha sido almacenado correctamente";
    }
    //Cerrar la conexión con el servidor de datos//
    $cnx->close();
?>