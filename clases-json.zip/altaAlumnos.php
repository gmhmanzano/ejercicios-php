<?php
    require_once("ficha.php");
    require_once("fichaAlumno.php");
    $alumno = new FichaAlumno();
    $notas = array(
        "nota1"   => $_POST['nota1'],
        "nota2"    => $_POST['nota2'],
        "nota3"    => $_POST['nota3']
    );
    $alumno->nif = $_POST['nif'];
    $alumno->apellidos = $_POST['apellidos'];
    $alumno->nombre = $_POST['nombre'];
    $alumno->curso = $_POST['curso'];
    $alumno->calificaciones = array($_POST['nota1'],$_POST['nota2'],$_POST['nota3']);
    $fichero = fopen("datos/alumnos.json","a");
    $json = json_encode(array($alumno));
    fputs($fichero,$json);
    fclose($fichero);
?>