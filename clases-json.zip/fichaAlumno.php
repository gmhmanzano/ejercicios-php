<?php
    class FichaAlumno extends FichaTic 
    {
        var $curso;
        var $calificaciones = array();
    }
?>
