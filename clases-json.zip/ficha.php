<?php
    class FichaTic 
    {
        var $nif;
        var $apellidos;
        var $nombre;

    }
?>
