<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Alta de profesores</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    </head>
    <body>
        <div class="container pt-3">
            <div class="row bg-light">
                <div class="col-8 offset-2 pt-2">
                    <form name="form1" action="altaAlumnos.php" method="POST">
                        <div class="form-group">
                            <label>NIF Alumno</label>
                            <input type="text" name="nif" id="nif" required="required" maxlength="10" class="form-control col-4">
                        </div>
                        <div class="form-group">
                            <label>Apellidos</label>
                            <input type="text" name="apellidos" id="apellidos" required="required" maxlength="50" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Nombre</label>
                            <input type="text" name="nombre" id="nombre" required="required" maxlength="50" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Curso</label>
                            <select name="curso" id="curso" required="required" class="form-control col-6">
                                <option value="" selected="selected" disabled="disabled" >Selecciona un curso</option>
                                <?php
                                    $fichero =fopen("cursos.json","r");
                                    $data = json_decode(fgets($fichero));
                                    foreach($data as $valor){
                                        echo "<option value='$valor'>$valor</option>";
                                    }
                                    fclose($fichero);    
                                ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Nota 1</label>
                            <input type="number" name="nota1" id="nota1" required="required"  class="form-control col-4" min="0">
                        </div>
                        <div class="form-group">
                            <label>Nota 2</label>
                            <input type="number" name="nota2" id="nota2" required="required"  class="form-control col-4" min="0">
                        </div>
                        <div class="form-group">
                            <label>Nota 3</label>
                            <input type="number" name="nota3" id="nota3" required="required"  class="form-control col-4" min="0">
                        </div>
                        <div class="form-group">
                            <input type="submit" value="Enviar Datos" class="btn btn-primary">
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    </body>
</html>