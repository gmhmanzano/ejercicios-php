<?php
    class FichaProfe extends FichaTic
    {
        var $salario;
        var $irpf;
        var $neto;
        function __construct($salario,$irpf)
        {
            $this->salario = $salario;
            $this->irpf = $irpf;
            $descuento = ($this->salario * $this->irpf)/100;
            $this->neto = $this->salario - $descuento;
        }
    }
?>
