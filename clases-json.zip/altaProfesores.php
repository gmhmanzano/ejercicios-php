<?php
    require_once("ficha.php");
    require_once("fichaProfe.php");
    //creamos el objeto de la clase FichaProfe//
    $profesor = new FichaProfe($_POST['salario'],$_POST['irpf']);
    //Añadimos a las propiedades los elementos del POST//
    $profesor->nif = $_POST['nif']; //propiedad heredada de FichaTic//
    $profesor->apellidos = $_POST['apellidos']; //propiedad heredada de FichaTic//
    $profesor->nombre = $_POST['nombre']; //propiedad heredada de FichaTic//
    $json = array();
    array_push($json,$profesor); //Se agrega al array el objeto $profesor//
    $json_encode = json_encode($json); //Se convierte el array a json//
    if(!file_exists("datos")){
        mkdir("datos");
    }
    $fichero = fopen("datos/profesores.json","a");
    fputs($fichero,$json_encode); //grabamos en el fichero el json//
    fclose($fichero);
?>
